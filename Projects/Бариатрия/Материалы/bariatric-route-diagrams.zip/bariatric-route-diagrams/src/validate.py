# -*- coding: utf-8 -*-
"""Геометрическая проверка схем.

Запуск: python3 src/validate.py
Код возврата 0 — дефектов нет, 1 — есть.

Разбирает готовые SVG и по метрикам шрифта пересчитывает габариты каждой
надписи. Проверяет три класса дефектов:
  1) текст выходит за пределы полотна;
  2) текст выходит за границы своего (наименьшего охватывающего) блока;
  3) надписи накладываются друг на друга.
"""
import glob, os, sys
import xml.etree.ElementTree as ET
from PIL import ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SVG_DIR = os.path.join(ROOT, "out", "svg")


def font_dir():
    for d in (os.path.join(ROOT, "fonts"), "/usr/share/fonts/truetype/dejavu/",
              "/usr/share/fonts/dejavu/", "/usr/local/share/fonts/",
              "/Library/Fonts/", "C:/Windows/Fonts/"):
        if os.path.exists(os.path.join(d, "DejaVuSans.ttf")):
            return d if d.endswith(os.sep) else d + os.sep
    raise SystemExit("Не найден DejaVuSans.ttf — положите шрифты DejaVu в папку fonts/.")


FD = font_dir()
_F = {}
def _f(b, i):
    k = (bool(b), bool(i))
    if k not in _F:
        n = {(0, 0): "DejaVuSans.ttf", (1, 0): "DejaVuSans-Bold.ttf",
             (0, 1): "DejaVuSans-Oblique.ttf", (1, 1): "DejaVuSans-BoldOblique.ttf"}[(int(k[0]), int(k[1]))]
        _F[k] = ImageFont.truetype(FD + n, 100)
    return _F[k]

def tw(s, fs, b=False, i=False):
    return _f(b, i).getlength(s) * fs / 100.0


NS = "{http://www.w3.org/2000/svg}"

def boxes(path):
    root = ET.parse(path).getroot()
    vb = [float(v) for v in root.get("viewBox").split()]
    W, H = vb[2], vb[3]
    texts, rects = [], []
    for el in root.iter():
        tag = el.tag.replace(NS, "")
        if tag == "text":
            s = el.text or ""
            if not s.strip():
                continue
            fs = float(el.get("font-size", 16))
            bold = el.get("font-weight") == "bold"
            ital = el.get("font-style") == "italic"
            anc = el.get("text-anchor", "start")
            x, y = float(el.get("x")), float(el.get("y"))
            w = tw(s, fs, bold, ital)
            x0 = x - w / 2 if anc == "middle" else (x - w if anc == "end" else x)
            texts.append(dict(s=s, x0=x0, x1=x0 + w, y0=y - fs * 0.80, y1=y + fs * 0.24, fs=fs))
        elif tag == "rect":
            rects.append((float(el.get("x", 0)), float(el.get("y", 0)),
                          float(el.get("width")), float(el.get("height"))))
    return W, H, texts, rects


def check(path):
    W, H, texts, rects = boxes(path)
    problems = []
    for t in texts:
        if t["x0"] < 1 or t["x1"] > W - 1 or t["y0"] < 0 or t["y1"] > H:
            problems.append(f"ЗА ХОЛСТ: «{t['s'][:52]}»  x[{t['x0']:.0f},{t['x1']:.0f}] "
                            f"y[{t['y0']:.0f},{t['y1']:.0f}] при {W:.0f}x{H:.0f}")
    for t in texts:
        cx, cy = (t["x0"] + t["x1"]) / 2, (t["y0"] + t["y1"]) / 2
        best = None
        for (rx, ry, rw, rh) in rects:
            if rw >= W - 4 and rh >= H - 4:      # фоновая подложка
                continue
            if rx <= cx <= rx + rw and ry <= cy <= ry + rh:
                if best is None or rw * rh < best[2] * best[3]:
                    best = (rx, ry, rw, rh)
        if best:
            rx, ry, rw, rh = best
            if t["x0"] < rx + 1.5 or t["x1"] > rx + rw - 1.5 or t["y0"] < ry - 1 or t["y1"] > ry + rh + 1:
                problems.append(f"ИЗ БЛОКА: «{t['s'][:52]}»  текст x[{t['x0']:.0f},{t['x1']:.0f}] "
                                f"блок x[{rx:.0f},{rx+rw:.0f}] y[{ry:.0f},{ry+rh:.0f}] "
                                f"текст y[{t['y0']:.0f},{t['y1']:.0f}]")
    for a in range(len(texts)):
        for b in range(a + 1, len(texts)):
            A, B = texts[a], texts[b]
            ox = min(A["x1"], B["x1"]) - max(A["x0"], B["x0"])
            oy = min(A["y1"], B["y1"]) - max(A["y0"], B["y0"])
            if ox > 2 and oy > 2:
                problems.append(f"НАЛОЖЕНИЕ: «{A['s'][:34]}» ↔ «{B['s'][:34]}» "
                                f"(перекрытие {ox:.0f}x{oy:.0f})")
    return problems


if __name__ == "__main__":
    files = sorted(glob.glob(os.path.join(SVG_DIR, "*.svg")))
    if not files:
        raise SystemExit(f"В {SVG_DIR} нет SVG. Сначала выполните: python3 src/diagrams.py")
    total = 0
    for p in files:
        pr = check(p)
        total += len(pr)
        print(f"\n=== {os.path.basename(p)} — проблем: {len(pr)}")
        for x in pr[:25]:
            print("   ", x)
    print(f"\nВСЕГО ПРОБЛЕМ: {total}")
    if total == 0:
        print("Все надписи в границах своих блоков, наложений нет.")
    sys.exit(1 if total else 0)
