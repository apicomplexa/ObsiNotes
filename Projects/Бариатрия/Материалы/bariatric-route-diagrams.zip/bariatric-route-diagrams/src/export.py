# -*- coding: utf-8 -*-
"""Экспорт схем в PNG высокого разрешения, SVG и PDF + сборка архива.

Запуск:    python3 src/export.py   (после diagrams.py)
Результат: dist/Схемы_маршрута_бариатрического_пациента.zip
"""
import os, shutil, zipfile
import xml.etree.ElementTree as ET
import cairosvg

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(REPO, "out", "svg")
ROOT = os.path.join(REPO, "dist", "_build")
BASE = os.path.join(ROOT, "Схемы_маршрута_бариатрического_пациента")
TARGET_PX = 4000          # ширина растрового варианта
PRINT_W_MM = 170          # предполагаемая ширина при вставке в документ

NAMES = {
    "s1_marshrut":      "Схема_1_Общая_карта_маршрута",
    "s2_ochered":       "Схема_2_Точки_входа_и_постановка_в_очередь",
    "s3_obsledovanie":  "Схема_3_Догоспитальное_обследование",
    "s4_stacionar":     "Схема_4_Стационарный_этап_по_суткам",
    "s5_pitanie":       "Схема_5_Пищевая_и_физическая_реабилитация",
    "s6_nabludenie":    "Схема_6_График_пожизненного_наблюдения",
    "s7_centr":         "Схема_7_Фрагментированная_модель_и_единый_центр",
}
TITLES = {
    "s1_marshrut": "Общая карта маршрута бариатрического пациента",
    "s2_ochered": "Точки входа в маршрут и порядок постановки в очередь",
    "s3_obsledovanie": "Догоспитальное обследование: три параллельных потока",
    "s4_stacionar": "Стационарный этап: план по суткам",
    "s5_pitanie": "Пищевая и физическая реабилитация после операции",
    "s6_nabludenie": "График пожизненного диспансерного наблюдения",
    "s7_centr": "Фрагментированная модель и модель единого центра",
}

if not os.path.isdir(SRC) or not os.listdir(SRC):
    raise SystemExit(f"В {SRC} нет SVG. Сначала выполните: python3 src/diagrams.py")

if os.path.exists(ROOT):
    shutil.rmtree(ROOT)
for sub in ("PNG (высокое разрешение)", "SVG (вектор)", "PDF (вектор)"):
    os.makedirs(os.path.join(BASE, sub))

rows = []
for key in sorted(NAMES):
    src = os.path.join(SRC, key + ".svg")
    vb = ET.parse(src).getroot().get("viewBox").split()
    w, h = float(vb[2]), float(vb[3])
    scale = TARGET_PX / w
    px_w, px_h = round(w * scale), round(h * scale)
    dpi = round(px_w / (PRINT_W_MM / 25.4))

    cairosvg.svg2png(url=src, scale=scale, background_color="white",
                     write_to=os.path.join(BASE, "PNG (высокое разрешение)", NAMES[key] + ".png"))
    cairosvg.svg2pdf(url=src, write_to=os.path.join(BASE, "PDF (вектор)", NAMES[key] + ".pdf"))
    shutil.copy(src, os.path.join(BASE, "SVG (вектор)", NAMES[key] + ".svg"))
    rows.append((NAMES[key], TITLES[key], px_w, px_h, dpi))
    print(f"{NAMES[key]:52} {px_w}x{px_h} px  ~{dpi} dpi")

readme = ["СХЕМЫ МАРШРУТА ПАЦИЕНТА БАРИАТРИЧЕСКОГО ПРОФИЛЯ", "=" * 62, "",
          "Комплект из 7 схем в трёх форматах. Оформление монохромное,",
          "рассчитано на чёрно-белую печать.", "",
          "СОДЕРЖИМОЕ", "-" * 62,
          "SVG (вектор)  — исходники, масштабируются без потери качества,",
          "                текст редактируется в Inkscape и Adobe Illustrator.",
          "                Предпочтительный формат для вёрстки и правок.",
          "PDF (вектор)  — для вставки в статьи, отчёты и презентации,",
          "                открывается без специальных программ.",
          "PNG           — растр высокого разрешения для программ,",
          "                не принимающих вектор (часть шаблонов PowerPoint,",
          "                веб-публикации).", "",
          "ПАРАМЕТРЫ ФАЙЛОВ", "-" * 62]
for name, title, pw, ph, dpi in rows:
    readme.append(f"{name}")
    readme.append(f"    {title}")
    readme.append(f"    PNG: {pw} x {ph} пикс.; при ширине {PRINT_W_MM} мм — около {dpi} dpi")
readme += ["", "ВСТАВКА В ДОКУМЕНТ", "-" * 62,
           f"Схемы рассчитаны на ширину {PRINT_W_MM} мм (полоса набора A4 при полях 25/15 мм).",
           "Разрешение PNG при такой ширине превышает 600 dpi, поэтому схемы",
           "пригодны и для типографской печати, и для увеличения фрагментов.",
           "При вставке сохраняйте пропорции: искажение соотношения сторон",
           "нарушает выравнивание текста внутри блоков.", "",
           "Схема 1 при ширине полосы занимает почти всю высоту страницы —",
           "её удобнее размещать на отдельной странице.", "",
           "ШРИФТ", "-" * 62,
           "DejaVu Sans. В SVG шрифт указан по имени, не внедрён: при",
           "редактировании на машине без DejaVu Sans подставится системный",
           "шрифт и ширина строк изменится. В PDF и PNG начертание",
           "зафиксировано, замена шрифта не требуется.", ""]
open(os.path.join(BASE, "О комплекте.txt"), "w", encoding="utf-8").write("\n".join(readme))

os.makedirs(os.path.join(REPO, "dist"), exist_ok=True)
zip_path = os.path.join(REPO, "dist", "Схемы_маршрута_бариатрического_пациента.zip")
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for dirpath, _, files in os.walk(BASE):
        for f in sorted(files):
            full = os.path.join(dirpath, f)
            z.write(full, os.path.relpath(full, ROOT))
print("\nархив:", zip_path, round(os.path.getsize(zip_path) / 1048576, 1), "МБ")
