---
tags:
  - "🎬grw"
status: "🟡 In Plans"
🎬Автор:
🎬Тип: "Аниме"
🎬Жанры:
  - "Драма"
🎬Оценка:
summary:
image: "![[Pasted image 20240612115643.png]]"
---
![[Pasted image 20240612115643.png]]